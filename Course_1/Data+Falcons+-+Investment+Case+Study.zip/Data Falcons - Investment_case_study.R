library(dplyr)
library(countrycode)
library(stringr)
library(tidyr)

# Data Cleaning
# 0. Load companies and rounds data into two data frames

companies <- read.delim("companies.txt", sep = '\t', header = TRUE, stringsAsFactors = FALSE, na.strings=c("","NA"))
rounds2 <- read.csv("rounds2.csv", stringsAsFactors = FALSE, na.strings=c("","NA"))

# 1.1 Understand the dataset

# 1. How many unique companies are present in rounds2?

companies$permalink <- tolower(companies$permalink)
rounds2$company_permalink <- tolower(rounds2$company_permalink)

count(distinct(rounds2, company_permalink))

# 2. How many unique companies are present in companies?

count(distinct(companies, permalink))

# 3. In the companies data frame, which column can be used as the unique key for each company? 
#    Write the name of the column.
# Answer: permalink

# By runing this query we will get zero record which means there is 
#no duplicate record based on group of permalink
companies %>%
  count(permalink) %>%
  filter(n>1)


#4. Are there any companies in the rounds2 file which are not present in companies ? Answer Y/N.
#Answer: No
# We can check by this query 
rounds2 %>%
  left_join(companies, by= c("company_permalink"="permalink")) %>%
  filter(is.na(name)==TRUE)


# 5. Merge the two data frames so that all variables (columns)
# in the companies frame are added to the rounds2 data frame. 
# Name the merged frame master_frame. 
# How many observations are present in master_frame?

colnames(rounds2) [1] <- "permalink"
master_frame <- merge(companies, rounds2, by = "permalink")
nrow(master_frame)



#Funding Type Analysis
# 2.1 Average Values of Investments for Each of these Funding Types

funding_type <- group_by(master_frame, funding_round_type)
average_funding <- summarise(funding_type, avg_funding=mean(raised_amount_usd, na.rm = T))
average_funding

# Considering that Spark Funds wants to invest between 5 to 15 million USD per investment round, 
# which investment type is the most suitable for them?

best_investment_type <- filter(average_funding, avg_funding>=5000000, avg_funding<=15000000)
best_investment_type

# Country Analysis
# Spark Funds wants to see the top nine countries which have received the highest total funding 
# (across ALL sectors for the chosen investment type)

# For the chosen investment type, make a data frame named top9 with the top nine countries 
# (based on the total investment amount each country has received)

# Creating a data frame with funding type 'vector'
best_fund_df <- subset(master_frame, master_frame$funding_round_type==best_investment_type$funding_round_type)

#Creating a column to show names of the countries
best_fund_df$country_name <- countrycode(best_fund_df$country_code, 'iso3c', 'country.name')

#Creating a data frame with NA country names removed
best_fund_df <- subset(best_fund_df, is.na(best_fund_df$country_name)==FALSE)

#Crouping the data by Country Name
country_group <- group_by(best_fund_df, country_name)

#Creating a data frame with top countries as per Funding
top_countries <- summarise(country_group, raised_amount_usd = sum(raised_amount_usd,na.rm = T))

#Sorting the data frame by funding received
top_countries_sorted <- top_countries[order(top_countries$raised_amount_usd, decreasing = TRUE),] 

#Data Frame with top 9 countries
top9 <- top_countries_sorted[1:9,]
top9

# create laugauage of top9 country
language <- c('English','Non-English','English','English','English','Non-English','Non-English','Non-English','Non-English')

#Add laguage to top9 data frame
top9 <- cbind(top9,language)


# Sector Analysis 1

# 1. Extract the primary sector of each category list from the category_list column

primary_sector <- sapply(strsplit(master_frame$category_list, "\\|"),function(x) x[1])

#Creating a data frame to combine master_frame and primary_sector
master_frame2 <- cbind(master_frame, primary_sector)

#Data cleaning exercise: Fix '0' in text with 'na'
master_frame2$primary_sector <- str_replace_all(master_frame2$primary_sector, 
                                                pattern = "0", replacement = "na")

## fix Enterprise 2.na
master_frame2$primary_sector <- str_replace(master_frame2$primary_sector,
                                            "Enterprise 2.na", "Enterprise 2.0")

#Convert primary_sector to lower case for merging
master_frame2$primary_sector <- tolower(master_frame2$primary_sector)

# 2. Use the mapping file 'mapping.csv' to map each primary sector to one of the eight main sectors

mapping <- read.csv("mapping.csv", stringsAsFactors = FALSE, na.strings=c("","NA"))
mapping <- gather(mapping, main_sector, my_val, Automotive...Sports:Social..Finance..Analytics..Advertising)
mapping <- mapping[!(mapping$my_val==0),]
mapping <- mapping[,-3]
colnames(mapping) <- c("primary_sector","main_sector")
mapping <- subset(mapping, !mapping$main_sector=="Blanks")

#Data cleaning exercise: Fix '0' in text with 'na
mapping$primary_sector <- str_replace_all(mapping$primary_sector, pattern = "0", replacement = "na")
mapping$primary_sector <- str_replace(mapping$primary_sector,
                                            "Enterprise 2.na", "Enterprise 2.0")

#Convert primary_sector to lower case for merging
mapping$primary_sector <- tolower(mapping$primary_sector)

#Creating a data frame to merge master_frame2 and mapping
master_frame3 <- merge(master_frame2,mapping,by="primary_sector", all.x=T)
master_frame3 <- filter(master_frame3, !is.na(main_sector))

#Add country name column
master_frame3$country_name <- countrycode(master_frame3$country_code, 'iso3c', 'country.name')

# Sector Analysis 2
# Create three separate data frames D1, D2 and D3

#Temporary creating C1, C2 and C3
C1 <- filter(master_frame3, country_name=="United States", funding_round_type=="venture", 
             raised_amount_usd>=5000000, raised_amount_usd<=15000000)
C2 <- filter(master_frame3, country_name=="United Kingdom", funding_round_type=="venture",
             raised_amount_usd>=5000000, raised_amount_usd<=15000000)
C3 <- filter(master_frame3, country_name=="India", funding_round_type=="venture",
             raised_amount_usd>=5000000, raised_amount_usd<=15000000)

C1_group <- group_by(C1, main_sector)
C1_investment <- summarise(C1_group, no_of_investments=n(),total_amt_invested=sum(raised_amount_usd))
D1 <- merge(C1, C1_investment,by="main_sector")

C2_group <- group_by(C2, main_sector)
C2_investment <- summarise(C2_group, no_of_investments=n(),total_amt_invested=sum(raised_amount_usd))
D2 <- merge(C2, C2_investment,by="main_sector")

C3_group <- group_by(C3, main_sector)
C3_investment <- summarise(C3_group, no_of_investments=n(),total_amt_invested=sum(raised_amount_usd))
D3 <- merge(C3, C3_investment,by="main_sector")

# Table 5.1
# Total number of investments
nrow(D1)
nrow(D2)
nrow(D3)

#Total amount of investment (USD)
sum(D1$raised_amount_usd, na.rm = TRUE)
sum(D2$raised_amount_usd, na.rm = TRUE)
sum(D3$raised_amount_usd, na.rm = TRUE)

#Top sector (based on count of investments)

USA_top3 <- head(arrange(C1_investment,desc(no_of_investments)),n=3)
USA_top3
GBR_top3 <- head(arrange(C2_investment,desc(no_of_investments)),n=3)
GBR_top3
IND_top3 <- head(arrange(C3_investment,desc(no_of_investments)),n=3)
IND_top3

# For top sector, company that received the highest investment

D1_top_sector <- subset(D1,D1$main_sector==USA_top3$main_sector[1]) %>%
  group_by(name) %>%
  summarise(total_amt=sum(raised_amount_usd))%>%
  arrange(desc(total_amt))
D1_top_sector

D2_top_sector <- subset(D2,D2$main_sector==GBR_top3$main_sector[1]) %>%
  group_by(name) %>%
  summarise(total_amt=sum(raised_amount_usd))%>%
  arrange(desc(total_amt))
D2_top_sector

D3_top_sector <- subset(D3,D3$main_sector==IND_top3$main_sector[1]) %>%
  group_by(name) %>%
  summarise(total_amt=sum(raised_amount_usd))%>%
  arrange(desc(total_amt))
D3_top_sector

# For second-best sector, company that recieved the highest investment

D1_top2_sector <- subset(D1,D1$main_sector==USA_top3$main_sector[2]) %>%
  group_by(name) %>%
  summarise(total_amt=sum(raised_amount_usd))%>%
  arrange(desc(total_amt))
D1_top2_sector

D2_top2_sector <- subset(D2,D2$main_sector==GBR_top3$main_sector[2]) %>%
  group_by(name) %>%
  summarise(total_amt=sum(raised_amount_usd))%>%
  arrange(desc(total_amt))
D2_top2_sector

D3_top2_sector <- subset(D3,D3$main_sector==IND_top3$main_sector[2]) %>%
  group_by(name) %>%
  summarise(total_amt=sum(raised_amount_usd))%>%
  arrange(desc(total_amt))
D3_top2_sector

# Plots

#Creating a data frame for Plot 3
master_frame4 <- master_frame3 %>%
  filter(funding_round_type=='venture' & raised_amount_usd >=5000000
         & raised_amount_usd <= 15000000 
         & ( (country_code=='USA' & (main_sector=='Others' 
                                     | main_sector=='Social..Finance..Analytics..Advertising' 
                                     | main_sector=='Cleantech...Semiconductors' ) ) 
             | (country_code=='GBR' & (main_sector=='Others' 
                                       | main_sector=='Social..Finance..Analytics..Advertising' 
                                       | main_sector=='Cleantech...Semiconductors' ) ) 
             | (country_code=='IND' & (main_sector=='Others' 
                                       | main_sector=='Social..Finance..Analytics..Advertising' 
                                       | main_sector=='News..Search.and.Messaging' ) ) ) )

#for Plot 1
write.csv(master_frame, "investment_final.csv", row.names = FALSE)

#for Plot 2
write.csv(top9,"investment_top.csv", row.names = FALSE)

#for Plot 3
write.csv(master_frame4, "investment_final2.csv", row.names = FALSE)


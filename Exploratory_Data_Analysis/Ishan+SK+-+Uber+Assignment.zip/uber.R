#Load required libraries
library(dplyr)
library(tidyr)
library(ggplot2)

#Extract the data into R
uber <- read.csv("Uber Request Data.csv")

str(uber)
summary(uber)

#Check for Duplicates in Request ID
sum(duplicated(uber$Request.id))
# no duplicates

#Check for NA values in Request id
sum(is.na(uber$Request.id))
#No NA values

#Check for Blanks
sapply(uber, function(x) length(which(x == "")))
#No Blanks

#Check for NA values in drop time
sum(is.na(uber$Drop.timestamp))
#NA values because of trip cancelled or no driver available

#Check for NA values in Driver id
sum(is.na(uber$Driver.id))
#Na values for no driver available

#Number of unique drivers
length(levels(as.factor(uber$Driver.id)))
#There are 300 drivers

#Convert Request time to a standard datetime format

#converting and storing datetimes of different formats in separate columns
uber$new_request_date <- as.POSIXct(uber$Request.timestamp, format = "%d/%m/%Y %H:%M")
uber$new_request_date2 <- as.POSIXct(uber$Request.timestamp, format = "%d-%m-%Y %H:%M:%S")

#Combining the columns into one
uber$new_request_date[which(is.na(uber$new_request_date))]<-uber[which(is.na(uber$new_request_date)),c('new_request_date2')]
#Checking type of datetime variable
typeof(uber$new_request_date)
#Data Cleaning and Manipulation
uber$new_request_date2 <- NULL
uber$Request.timestamp <- uber$new_request_date
uber$new_request_date <- NULL

#Convert drop time to a standard datetime format

#converting and storing datetimes of different formats in separate columns
uber$new_drop_date <- as.POSIXct(uber$Drop.timestamp, format = "%d/%m/%Y %H:%M")
uber$new_drop_date2 <- as.POSIXct(uber$Drop.timestamp, format = "%d-%m-%Y %H:%M:%S")

#Combining the columns into one
uber$new_drop_date[which(is.na(uber$new_drop_date))]<-uber[which(is.na(uber$new_drop_date)),c('new_drop_date2')]
#Checking type of datetime variable
typeof(uber$new_drop_date)
#Data Cleaning and Manipulation
uber$new_drop_date2 <- NULL
uber$Drop.timestamp <-uber$new_drop_date
uber$new_drop_date <- NULL

#Checking frequency of trip requests based on day of the week
summary(as.factor(weekdays(uber$Request.timestamp)))
#there does not appear much difference in frequency

#Calculate and store trip duration
uber$duration<-round(uber$Drop.timestamp-uber$Request.timestamp,2)

#Univariate analysis on Duration of trips
summary(unclass(uber$duration))
#Mean duration of a trip to/from Airport is around 52 minutes

#Checking if there is any difference in trip duration across pickup point
ggplot(uber,aes(y=as.numeric(duration),x=Pickup.point))+geom_boxplot(na.rm = T)
#trips to and from airport have similar duration


#Store hour of request time in a different column for analysis
uber$request_hour <- as.numeric(format(uber$Request.timestamp, "%H"))

#Store day of request in a different column for analysis
uber$request_day <- as.numeric(format(uber$Request.timestamp, "%d"))

#Check frequency of trip requests each day
summary(as.factor(uber$request_day))
#no significant difference

#Plot perecntage of trip requests each day and analyse any changes in trip status
ggplot(uber, aes(x = request_day, fill=factor(Status))) + geom_bar() +facet_wrap(~Pickup.point)

#There is high proportion of trip requests with Airport pickup for which cars are unavailable 
#No significant change across days

#Bivariate Analysis - Checking if there is any affect on duration across hour and day of trip request
cor(x = as.numeric(uber$duration),y = uber$request_hour, "na.or.complete")

#There is low negative correlation between duration and hour
#Duration of trip is longer in the earlier half of the day
#This could be due to traffic

#Group request hours into bins showing time slots of the day

#Early Morining: 12 am - 6 am
#Morning: 6 am - 12pm
#Afternoon: 12pm - 4pm
#Evening: 4pm - 8pm
#Late Evening: 8pm to 12am

#Grouping of time slots done according to actual parts of the day. 
#Early Morning and Late Evening selected have also been selected 
# due to the demand for cars at these times 

uber$request_slot <- cut(uber$request_hour, 
                         breaks = c(0,6,12,16,20,23), include.lowest=TRUE,right = FALSE,
                         labels=c("Early Morning", "Morning", "Afternoon", "Evening", "Late Evening"))

uber$request_slot <- as.factor(uber$request_slot)

#Create a dataframe showing time slot of request time with frequency
slots <- uber %>%
  group_by(request_slot , request_hour) %>%
  summarise(frequency = n())

#plot the frequency of trip requests across time slots
slots$request_slot <- as.factor(slots$request_slot)
ggplot(slots, aes(x=request_slot, y=frequency, col=factor(request_slot))) + geom_point(shape = 2, size = 3)
#there seems to be more requests in the morning, evening and later half of late evening
#there are fewer trip requests at early morning and afternoon

#Summary of trip status
summary(uber$Status)
#Plot showing count of trip status (Univariate analysis)
ggplot(uber, aes(x=Status, fill=factor(Status))) + geom_bar() + labs(fill = "Trip Status")
#There is a high case of 'No cars available'

#Summary of pickup point
summary(uber$Pickup.point)
#Plot showing distribution of trip status across pickup points (Bivariate Analysis)
ggplot(uber, aes(x=Pickup.point, fill=factor(Status))) + geom_bar() + 
  labs(fill = "Trip Status", x = "Pickup Point", y = "Frequency", 
       title = "Distribution of Trip Status across pickup points")
#There is a high case of 'No cars available' for trip requests from the Airport to City
#Few trips get cancelled if booked at Airport
#Many trips booked from the City to Airport get cancelled or show 'No driver available'

#Creating subsets based on Pick-up point
uber_airport <- subset(uber, Pickup.point == "Airport")
uber_city <- subset(uber, Pickup.point == "City")

#Table showing Frequency of Trip status across time slots (Bivariate Analysis)
addmargins(table(uber$request_slot, uber$Status)) #Overall
addmargins(table(uber_airport$request_slot, uber_airport$Status)) #For trips from Airport to City
addmargins(table(uber_city$request_slot, uber_city$Status)) #For trips from City to Airport


#Table showing Proportion of Trip status across time slots (Bivariate Analysis)
#Proportion of values from left to right
prop.table(table(uber$request_slot, uber$Status),round(digits = 1)) %>%
  {. * 100} %>% round(2) #Overall
prop.table(table(uber_airport$request_slot, uber_airport$Status),round(digits = 1)) %>%
  {. * 100} %>% round(2) #For trips from Airport to City
prop.table(table(uber_city$request_slot, uber_city$Status),round(digits = 1)) %>%
  {. * 100} %>% round(2) #For trips from City to Airport

#For Airport pick-ups:
#Highest demand for cars is in the Evening and Late Evening
#But this demand is not met sufficiently. Cars are not available.

#For City pick-ups:
#Highest demand for cars is in the Morning
#But this demand is not met sufficiently. Drivers cancel the trip


#Plot showing trip status across time slots (Bivariate Analysis)
ggplot(uber, aes(x=request_slot, fill=factor(Status))) + geom_bar() + 
  labs(fill = "Trip Status", title = "Trip status distribution across Time slots", 
       x = "Time slot of trip request")

#Most trips are booked in the morning. Most trips are also cancelled in the morning
#There is a high case of unavailibility of cars during the evening and late evening

#Dodge plot showing trip status across time slots
ggplot(uber, aes(x=factor(request_slot), fill = factor(Status))) + 
  geom_bar(alpha = 0.5, position = position_dodge(width = 0.3))

#There is a higher chance of a trip getting completed if booking during Morning hours

#Plot showing trip status across time slots for Airport pickup
ggplot(subset(uber,Pickup.point=="Airport"), aes(x=request_slot, fill=factor(Status))) + geom_bar()

#Plot showing trip status across time slots for City pickup
ggplot(subset(uber,Pickup.point=="City"), aes(x=request_slot, fill=factor(Status))) + geom_bar()

#Plot showing trip status across time slots for both Airport and City pickup
ggplot(uber, aes(x=request_slot, fill=factor(Status))) + geom_bar() + facet_wrap(~Pickup.point)
#Zoom the plot to view time slot labels clearly

#For trip from Airport to City:
# Peak demand for cars are in the evening and late evening
# There is a high case of unavailibility of cars during evening and late evening (i.e. 4pm -12am)
# This could be because there wasn't any trip prior to this time from the City to Airport,
# hence creating an unavailability of cars at the Airport at the required time

#For trip from City to Airport:
# Peak demand for cars are in the morning 
# There is a high case of cancellation of trip for booking during morning hours (i.e. 6am -12pm)
# This could be because demand for cars at the Airport is low in the Afternoon
# and drivers would have to come back to the city without a passenger or wait for a long time.
# City traffic could be another reason for cancellation

#Plot showing Trip Status based on hour of trip request for both pickup points

ggplot(uber,aes(x=factor(request_hour),fill=factor(Status)))+geom_bar(stat="count")+facet_wrap(~Pickup.point)
#Peak booking hours for trip from Airport to City is between 5pm - 9pm. 
#Huge supply demand gap observed due to unavailibility of cars

#Peak booking hours for trip from City to Airport is between 5am - 9am. 
#Huge supply demand gap observed due to Trip cancellations



#Export as csv for Tableau
write.csv(uber, "uber.csv", row.names = FALSE)


#loading required R packages
library(tidyr)
library(dplyr)
library(stringr)
library(ggplot2)


#loading dataset into R
loan <- read.csv("loan.csv", stringsAsFactors = F, na.strings = c("", "NA"))

#setting na.strings attribute to replace all blank values with NA

str(loan)

### DATA CLEANING ###

#Checking for Duplicate id's
sum(duplicated(loan$id)) 
sum(duplicated(loan$member_id))
#no duplicates

#Checking for NA values
sapply(loan, function(x) length(which(is.na(x))))

#Dropping variables with all values as NA
loan <- loan[,sapply(loan, function(x) length(which(is.na(x)))) != 39717, drop = FALSE]

#Removing unnecessary variables with all values as 0 or NA
loan$collections_12_mths_ex_med <- NULL
loan$acc_now_delinq <- NULL
loan$chargeoff_within_12_mths <- NULL
loan$delinq_amnt <- NULL
loan$tax_liens <- NULL

#Converting selected variables into Factors
loan$grade <- as.factor(loan$grade)
loan$sub_grade <- as.factor(loan$sub_grade)
loan$purpose <- as.factor(loan$purpose)
loan$home_ownership <- as.factor(loan$home_ownership)
loan$verification_status <- as.factor(loan$verification_status)
loan$loan_status <- as.factor(loan$loan_status)
loan$application_type <- as.factor(loan$application_type)
loan$addr_state <- as.factor(loan$addr_state)
loan$pub_rec_bankruptcies <- as.factor(loan$pub_rec_bankruptcies)

### DATA MANIPULATION ###

#Removing "months" from 'term' variable
loan <- separate(loan, term, into = c("blanks", "term", "months_vector"), sep = " ")
loan$term <- as.numeric(loan$term)
loan$blanks <- NULL
loan$months_vector <- NULL

#Removing "%" from interest rate and revol_util
loan$int_rate <- as.numeric(gsub ("[%]", "", loan$int_rate))
loan$revol_util <- as.numeric(gsub ("[%]", "", loan$revol_util))

#Removing "xx" in zipcode
loan$zip_code <- gsub("xx","",loan$zip_code)

#Converting emp_length to a suitable format
loan$emp_length <- gsub("years", "", loan$emp_length)
loan$emp_length <- gsub("year", "", loan$emp_length)
loan$emp_length <- gsub("< 1", "0", loan$emp_length)
loan$emp_length <- gsub("[+]", "", loan$emp_length)

#Checking for NA values 
summary(as.factor(loan$emp_length))
#There are 1075 NA values

#Converting issue date into a Standard format
loan$issue_d <- as.Date(paste("01-",loan$issue_d, sep=""), format = "%d-%b-%y")
loan$last_pymnt_d <- as.Date(paste("01-",loan$last_pymnt_d, sep=""), format = "%d-%b-%y")
loan$last_credit_pull_d <- as.Date(paste("01-",loan$last_credit_pull_d,sep=""), format = "%d-%b-%y")
loan$earliest_cr_line <- as.Date(paste("01-",loan$issue_d,sep=""), format = "%d-%b-%y")
loan$next_pymnt_d <- as.Date(paste("01-",loan$next_pymnt_d,sep=""), format = "%d-%b-%y")

#Removing other unnecessary variables

#descriptive variables
loan$desc <- NULL
loan$emp_title <- NULL
loan$title <- NULL

#same format URL with id as the only difference
loan$url <- NULL

#all values same
loan$initial_list_status <- NULL
loan$application_type <- NULL
loan$policy_code <- NULL
loan$pymnt_plan <- NULL



### EXPLORATORY ANALYSIS ###


#Finding the Top 5 purpose for loan
head(loan %>%
       group_by(purpose) %>%
       summarise(frequency = n()) %>%
       arrange (desc(frequency)), 5)

#We see that Debt consolidation is the most popular reason for loan

#Checking the number of loans according to State

loan %>%
  group_by(addr_state) %>%
  summarise(frequency = n()) %>%
  arrange (desc(frequency))
#California has the highest numer of loans followed by New York and Florida

#Univariate analysis

#Analysis on loan status based on grade
addmargins(table(loan$grade, loan$loan_status))
prop.table(table(loan$grade, loan$loan_status),round(digits = 1)) %>%
{. * 100} %>% round(2)

ggplot(loan, aes(x= grade, fill= loan_status))+geom_bar(position = "fill") 
#From this plot we see that the level of delinquency increases from grades A to G


#Finding the Sub_Grade for the most frequent delinquent customer's Grade
loan %>%
  subset(loan$grade== "G") %>%
  ggplot(aes(x=sub_grade, fill= loan_status)) +geom_bar(position = "fill")
#From this plot we get G3 to be the most frequent delinquent customer's sub-grade


#Finding the term for which there is highest delinquency
loan$term <- as.factor(loan$term)
ggplot(loan, aes(x= term, fill = loan_status))+geom_bar() 
ggplot(loan, aes(x= term, fill = loan_status))+geom_bar(position = "fill") 
#From this plot we can observe that a term of 60 months attract a greater number of delinquents


#Finding the type of home_ownership for which there is highest delinquency

#Proportion table for loan status based on type of home ownership
prop.table(table(loan$home_ownership, loan$loan_status),round(digits = 1)) %>%
{. * 100} %>% round(2)

ggplot(loan, aes(x= home_ownership, fill = loan_status))+geom_bar()
#most loan customers have rented house or mortgage 

ggplot(loan, aes(x= home_ownership, fill = loan_status))+geom_bar(position = "fill")
#From this plot we find that 'OTHER' has the highest delinquents



#Derived Metrics

#interest rate group
loan$int_rate_grp <- cut(loan$int_rate, breaks = c(5,11,16,21,26), include.lowest = TRUE, right = FALSE,
                         labels = c("5-10", "11-15","16-20","21-25"))

ggplot(loan, aes(x= int_rate_grp, fill = loan_status))+geom_bar(position = "fill")
#Delinquency increases as the interest rate increases

# As the variable 'dti'includes both customer's monthly income and total monthly debt payments 
# it is good indicator to analyze delinquency

loan$dti_segment <- cut(loan$dti, breaks = c(0,6,11,16,21,26,31), include.lowest = TRUE, right = FALSE,
                    labels = c("0-5", "6-10","11-15","16-20","21-25","26-30"))

ggplot(loan, aes(x= dti_segment, fill = loan_status))+geom_bar()
ggplot(loan, aes(x= dti_segment, fill = loan_status))+geom_bar(position = "fill")
#This plot shows that most delinquents have a Debt to Income ratio in the 16-20 and 21-25 range

# Derived metrics - grouping work experience into slots

#Converting into numeric vector to use cut function
loan$emp_length <- as.numeric(loan$emp_length)
#creating slot
loan$emp_slot <- cut(loan$emp_length, breaks = c(0,3,6,10,11), include.lowest = TRUE, right = FALSE,
                     labels = c("0-2", "3-5","6-9","10 & above"))
#converting into factor for analysis
loan$emp_slot <- as.factor(loan$emp_slot)
summary(loan$emp_slot)

#Cross table showing  loan status according to work experience - frequency & proportion
addmargins(table(loan$emp_slot, loan$loan_status))
prop.table(table(loan$emp_slot, loan$loan_status),round(digits = 1)) %>%
{. * 100} %>% round(2)

#Plot showing Loan status as per work experience
ggplot(loan, aes(x=emp_slot, fill= loan_status))+
  geom_bar(position = "fill")
#data doesn't show any significant difference

#Checking the frequency according to number of bankruptcies
ggplot(loan, aes(x= pub_rec_bankruptcies))+geom_bar() + geom_text(stat='count', aes(label=..count..), vjust= -1)
#Most customers do not have a bankruptcy history

#Checking relationship between loan status and bankruptcies
ggplot(loan, aes(x= pub_rec_bankruptcies, fill = loan_status))+geom_bar(position = "fill")
#Chances of delinquency increases as number of bankruptcies increase



#Segmented univariate analysis

loan2 <- loan
  

#Finding 95th quartile for annual income
quantile(loan$annual_inc, 0.95)
#142000 

#95th quartile for loan amount
quantile(loan$loan_amnt, 0.95, na.rm = T)
#25000

#For annual_inc, Considering anything greater than 142000 as outlier and replacing it with 142000
loan2$annual_inc <- sapply(loan2$annual_inc, function(x) ifelse(x > 142000 ,142000,x))

#For loan_amnt, Considering anything greater than 25000 as outlier and replacing it with 25000
loan2$loan_amnt <- sapply(loan2$loan_amnt, function(x) ifelse(x > 25000 ,25000,x))

ggplot(loan2, aes(x= factor(loan_status), y = annual_inc ))+geom_boxplot()
#This plot shows that the median monthly salary of those who default on loans is lower compared to those who don't

ggplot(loan2, aes(x= factor(loan_status), y = loan_amnt ))+geom_boxplot()  
#This plot shows that the median of the loan amounts for the "charged-off" loans is nearly 10000

##Analysis on  revol_bal
#For loan_amnt, Considering anything greater than 25000 as outlier and replacing it with 25000
loan2$revol_bal <- sapply(loan2$revol_bal, function(x) ifelse(x > 50000 ,50000,x))

quantile(loan2[which(loan2$loan_status=='Charged Off'),"revol_bal"], probs = seq(0,1,0.25))
quantile(loan2[which(loan2$loan_status=='Current'),"revol_bal"], probs = seq(0,1,0.25))
quantile(loan2[which(loan2$loan_status=='Fully Paid'),"revol_bal"], probs = seq(0,1,0.25))

ggplot(loan2, aes(x= loan_status, y = revol_bal ))+geom_boxplot() 
#This plot we can see median of full paid and charged off is almost same, 
#This variable dont gives a trend

##Analysis on revol_util
quantile(loan2[which(loan2$loan_status=='Charged Off'),"revol_util"], probs = seq(0,1,0.25), na.rm = T)
quantile(loan2[which(loan2$loan_status=='Current'),"revol_util"], probs = seq(0,1,0.25), na.rm = T)
quantile(loan2[which(loan2$loan_status=='Fully Paid'),"revol_util"], probs = seq(0,1,0.25), na.rm = T)

ggplot(loan2, aes(x= loan_status, y = revol_util ))+geom_boxplot() 
##  This plot shows a trend that median decrease from Charged Off to Fully Paid. 


##Analysis on total_acc
ggplot(loan, aes(x= total_acc, fill= loan_status))+geom_histogram(position = "fill", binwidth = 5)

addmargins(table(loan$total_acc, loan$loan_status))
prop.table(table(loan$total_acc, loan$loan_status),round(digits = 1)) %>%
{. * 100} %>% round(2)
##  At total_acc 70 and 74, Charged Off is 100%, could be outlier.

#Analysis on total_pymnt
## calculate the percentage of amount overall paid
loan2$payment_Percentage <- (loan2$total_pymnt / loan2$loan_amnt) * 100

ggplot(loan2, aes(x= payment_Percentage, fill= loan_status))+geom_histogram(position = "fill", binwidth = 10)
## This plot show that defaulter are pre-decided for not to pay installment on time. 

##Analysis on total_rec_prncp 
## calculate the percentage of amount overall paid
loan2$total_rec_prncp_Percentage <- (loan2$total_rec_prncp / loan2$loan_amnt) * 100

ggplot(loan2, aes(x= total_rec_prncp_Percentage, fill= loan_status))+geom_histogram(position = "fill", binwidth = 10)
## Now from this we can clearly see defaulters are not paying even 50% of principal amount

##Analysis on last_pymnt_amnt
loan2$last_pymnt_amnt <- sapply(loan2$last_pymnt_amnt, function(x) ifelse(x > 5000 ,5000,x))

quantile(loan2[which(loan2$loan_status=='Charged Off'),"last_pymnt_amnt"], probs = seq(0,1,0.25))
quantile(loan2[which(loan2$loan_status=='Current'),"last_pymnt_amnt"], probs = seq(0,1,0.25))
quantile(loan2[which(loan2$loan_status=='Fully Paid'),"last_pymnt_amnt"], probs = seq(0,1,0.25))

ggplot(loan2, aes(x= loan_status, y = last_pymnt_amnt ))+geom_boxplot() 
## This plot shows that median of defaulter is less as compared to current and fully paid


## ANALYSIS OF DATE VARIABLES ##

#Checking a trend in loan default across years as per loan issue
loan$issue_yr <- as.factor(format(loan$issue_d, "%Y"))
summary(loan$issue_yr)
ggplot(loan, aes(x= issue_yr, fill = loan_status))+geom_bar(position = "fill")
#Cases of loan default have decreased for loans issued from 2007 to 2010 and slightly increased in 2011

#Checking a trend in loan default across years as per last payment
loan$last_pymnt_yr <- as.factor(format(loan$last_pymnt_d, "%Y"))
summary(loan$last_pymnt_yr)
ggplot(loan, aes(x= last_pymnt_yr, fill = loan_status))+geom_bar(position = "fill")
#Cases of loan default have decreased as the last payment date becomes recent

loan$last_credit_pull_yr <- as.factor(format(loan$last_credit_pull_d, "%Y"))
summary(loan$last_credit_pull_yr)
ggplot(loan, aes(x= last_credit_pull_yr, fill = loan_status))+geom_bar(position = "fill")
#loan default has decreased for last credit pull year from 2009 to 2015 and increased in 2016


## Exporting data frames as CSV for Tableau analysis
write.csv(loan, "loan1.csv", row.names = FALSE)
write.csv(loan2, "loan2.csv", row.names = FALSE)

